from fastapi import FastAPI
from pydantic import BaseModel
import pandas as pd
import joblib

# Load model
model = joblib.load("model/saved_model/ecommerce_model.pkl")

# Create FastAPI app
app = FastAPI()

# Request model
class CustomerData(BaseModel):
    age: int
    salary: int
    pages_viewed: int
    time_on_site: int
    discount_used: int
    previous_purchases: int
    cart_value: int

# Home route
@app.get("/")
def home():
    return {
        "message": "E-Commerce Purchase Prediction API"
    }

# Prediction route
@app.post("/predict")
def predict(data: CustomerData):

    # Feature Engineering
    engagement_score = (
        data.pages_viewed * data.time_on_site
    )

    # Create dataframe
    input_data = pd.DataFrame([[
        data.age,
        data.salary,
        data.pages_viewed,
        data.time_on_site,
        data.discount_used,
        data.previous_purchases,
        data.cart_value,
        engagement_score
    ]], columns=[
        "age",
        "salary",
        "pages_viewed",
        "time_on_site",
        "discount_used",
        "previous_purchases",
        "cart_value",
        "engagement_score"
    ])

    # Prediction
    prediction = model.predict(input_data)[0]

    result = (
        "Will Purchase"
        if prediction == 1
        else "Will Not Purchase"
    )

    return {
        "prediction": int(prediction),
        "result": result
    }