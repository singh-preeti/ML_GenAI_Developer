# E-Commerce Purchase Prediction Project

## Install Dependencies

pip install -r requirements.txt

---

## Train Model

python train_model.py

---

## Run FastAPI Server

uvicorn app:app --reload

---

## Swagger UI

http://127.0.0.1:8000/docs

---

## Docker Build

docker build -t ecommerce-ml-app .

---

## Docker Run

docker run -p 8000:8000 ecommerce-ml-app

---

## Run Tests

pytest