import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import joblib
import os

np.random.seed(42)

size = 5000

# Create dataset
data = pd.DataFrame({
    "age": np.random.randint(18, 60, size),
    "salary": np.random.randint(20000, 150000, size),
    "pages_viewed": np.random.randint(1, 50, size),
    "time_on_site": np.random.randint(1, 30, size),
    "discount_used": np.random.randint(0, 2, size),
    "previous_purchases": np.random.randint(0, 20, size),
    "cart_value": np.random.randint(500, 20000, size)
})

# Feature Engineering
data["engagement_score"] = (
    data["pages_viewed"] * data["time_on_site"]
)

# Target column
data["purchased"] = (
    (data["salary"] > 50000) &
    (data["time_on_site"] > 10) &
    (data["cart_value"] > 3000) &
    (data["engagement_score"] > 150)
).astype(int)

# Save dataset
os.makedirs("data", exist_ok=True)
data.to_csv("data/customer_data.csv", index=False)

# Features and target
X = data.drop("purchased", axis=1)
y = data["purchased"]

# Train test split
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# Random Forest Model
model = RandomForestClassifier(
    n_estimators=200,
    max_depth=10,
    min_samples_split=5,
    min_samples_leaf=2,
    random_state=42
)

# Train model
model.fit(X_train, y_train)

# Predictions
predictions = model.predict(X_test)

# Accuracy
accuracy = accuracy_score(y_test, predictions)

print("Model Accuracy:", accuracy)

# Save model
os.makedirs("model/saved_model", exist_ok=True)

joblib.dump(model, "model/saved_model/ecommerce_model.pkl")

print("Model saved successfully!")